let currentPlan = [], chart;
const $ = id => document.getElementById(id);
const escapeHTML = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
$("profileForm").addEventListener("submit", async e => {
  e.preventDefault(); $("error").textContent = ""; const button = e.submitter;
  button.disabled = true; button.textContent = "Generating...";
  try {
    const res = await fetch("/api/plan", { method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({budget:Number($("budget").value),diet:$("diet").value,goal:$("goal").value}) });
    const data = await res.json(); if (!res.ok) throw new Error(data.error || "Unable to generate plan.");
    currentPlan = data.meals; render(data); loadHistory();
  } catch(err) { $("error").textContent = err.message; }
  finally { button.disabled = false; button.textContent = "✨ Generate my meal plan"; }
});
function totals() {
  return currentPlan.reduce((a,m) => { ["calories","protein","carbs","fat"].forEach(k => a[k]+=m[k]); a.cost+=m.cost; return a; },
    {calories:0,protein:0,carbs:0,fat:0,cost:0});
}
function render(data) {
  $("results").classList.remove("hidden"); $("budgetPill").textContent = `₹${data.total} / ₹${data.budget}`;
  const t = totals();
  $("stats").innerHTML = [["Estimated calories",`${t.calories} kcal`],["Protein",`${t.protein} g`],["Carbohydrates",`${t.carbs} g`],["Fat",`${t.fat} g`]]
    .map(([a,b])=>`<div class="stat"><small>${a}</small><strong>${b}</strong></div>`).join("");
  $("mealGrid").innerHTML = currentPlan.map(m=>`<article class="meal"><div class="meal-top"><div><div class="eyebrow">${escapeHTML(m.meal.toUpperCase())}</div><h3>${escapeHTML(m.name)}</h3></div><div class="cost">₹${m.cost}</div></div>
    <div class="meal-meta">⏱ ${m.time} min • ${escapeHTML(m.type)}</div><div class="macroline"><span>🔥 ${m.calories} kcal</span><span>💪 ${m.protein}g protein</span><span>🍚 ${m.carbs}g carbs</span><span>🥑 ${m.fat}g fat</span></div>
    <details><summary>Ingredients & simple instructions</summary><p><b>Ingredients:</b> ${m.ingredients.map(x=>`${escapeHTML(x.name)} (${x.qty})`).join(", ")}</p><ol>${m.steps.map(s=>`<li>${escapeHTML(s)}</li>`).join("")}</ol></details>
    <button class="swap" onclick="swapMeal('${escapeHTML(m.id)}')">↻ Swap ${escapeHTML(m.meal)}</button></article>`).join("");
  drawChart(t); loadGroceries();
}
function drawChart(t) {
  if (!window.Chart) return;
  if (chart) chart.destroy();
  chart = new Chart($("macroChart"), {type:"doughnut",data:{labels:["Protein","Carbs","Fat"],datasets:[{data:[t.protein*4,t.carbs*4,t.fat*9],backgroundColor:["#1d7652","#d9a441","#a6c96a"],borderWidth:0}]},
    options:{cutout:"65%",plugins:{legend:{position:"bottom"}}}});
}
async function swapMeal(id) {
  const old=currentPlan.find(m=>m.id===id), used=currentPlan.filter(m=>m.id!==id).map(m=>m.id);
  const budgetLeft=Number($("budget").value)-currentPlan.reduce((s,m)=>s+m.cost,0)+old.cost;
  const res=await fetch("/api/swap",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({mealId:id,currentIds:used,budgetLeft,diet:$("diet").value,goal:$("goal").value})});
  const data=await res.json(); if(!res.ok){alert(data.error);return;}
  currentPlan=currentPlan.map(m=>m.id===id?data:m); render({total:totals().cost,budget:Number($("budget").value)});
}
async function loadGroceries() {
  const res=await fetch("/api/grocery",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({meals:currentPlan})});
  const data=await res.json();
  $("groceryList").innerHTML=`<p class="muted">Estimated 7-day spend if this same day is repeated: <b>₹${data.weeklyCost}</b></p>`+
    data.list.map(x=>`<div class="grocery-item"><span>${escapeHTML(x.name)} <small>· ${escapeHTML(x.category)}</small></span><b>${x.weeklyQty} units/week</b></div>`).join("");
}
async function loadHistory() {
  const res=await fetch("/api/history"); const history=await res.json();
  $("historyList").innerHTML=history.length ? history.map(p=>`<div class="grocery-item"><span>${new Date(p.createdAt).toLocaleString()} · ${escapeHTML(p.diet)} · ${escapeHTML(p.goal)}</span><b>₹${p.total} / ₹${p.budget}</b></div>`).join("") : "<p class='muted'>Your generated plans will appear here.</p>";
}
$("printBtn").addEventListener("click",()=>window.print());
loadHistory();
