# PlatePilot: NutriNinja Cup — 90+ Improvement Edition

This is an upgraded version of your original hackathon project. It preserves the original recipe data and interface while strengthening SQLite persistence, validating the recipe dataset at startup, adding structured request/error logs, request IDs, API documentation, stricter API validation, security middleware, saved plan history, improved diet filtering, and expanded automated tests.

## Requirements
- Node.js 18 or newer (LTS recommended)
- Internet connection for the first `npm install` and the Chart.js CDN used by the page

## Run on Windows
1. Extract this ZIP.
2. Open the extracted `PlatePilot_90Plus` folder.
3. In File Explorer, click the address bar, type `cmd`, and press Enter.
4. Run:

```bash
npm install
npm start
```

5. Open http://localhost:3000 in Chrome.

To stop the server, return to the terminal and press `Ctrl + C`.

## Run tests
In the same folder, run:

```bash
npm test
```

The tests cover diet filtering, budget constraints, meal-slot selection, scoring, recipe data integrity, API validation, malformed JSON, grocery aggregation, history persistence, meal swaps, request IDs, and health metadata.

## New / improved features
- SQLite persistence using SQL.js; the database is stored in `data/platepilot.sqlite`.
- Saved recent meal-plan history (`GET /api/history`).
- Zod validation for plan, swap, and grocery API requests.
- Helmet security headers, JSON body size limit, API rate limiting, and disabled Express fingerprint header.
- Safer HTML rendering for recipe text.
- Correct Vegetarian and Vegan filtering; Non-Veg preference allows all recipe categories.
- More predictable error responses with request IDs for troubleshooting.
- Atomic database file replacement using a cloned database, so failed disk writes do not mutate the active in-memory database.
- Startup validation for recipe IDs, required fields, numeric values, and ingredient/step arrays.
- Structured JSON request and error logs with request duration.
- API reference in `docs/API.md` and optional settings in `.env.example`.
- Modular planner and database code under `src/`.

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Health check |
| GET | `/api/recipes` | List recipes |
| POST | `/api/plan` | Generate and save a daily plan |
| POST | `/api/swap` | Replace one meal |
| POST | `/api/grocery` | Build grocery list |
| GET | `/api/history` | Get last 20 saved plans |

## Project structure
```text
PlatePilot_90Plus/
├── data/
│   ├── recipes.json
│   └── platepilot.sqlite       # created automatically at first run
├── public/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── src/
│   ├── database.js
│   └── planner.js
├── tests/
│   └── planner.test.js
├── docs/
│   └── API.md
├── .env.example
├── package.json
└── server.js
```

## Demo checklist for judging
1. Start the app and show the responsive dashboard.
2. Generate a plan using a small budget, then show the budget total.
3. Change diet to Vegan and show that every selected meal is vegan.
4. Swap a meal and show the budget stays within the limit.
5. Show the grocery list and macro chart.
6. Refresh the page and show saved plan history remains.
7. Run `npm test` and show passing automated tests.
8. Open `/api/health` to demonstrate the backend health endpoint.

## Honest project limitations
- Recipe prices and nutrition figures are illustrative values from the supplied dataset; verify local prices and portions before claiming real-world accuracy.
- The meal selection is a heuristic, not a clinical nutrition recommendation.
- The app does not yet provide user accounts, multi-user authorization, cloud deployment, or a professionally verified nutrition database.
- SQL.js is SQLite compiled to WebAssembly; it persists the database file on disk. It is suitable for a student prototype/demo, but a production multi-user service should use a managed database and proper migrations, backups, authentication, and authorization.

## Important
No software change can guarantee a 90+ evaluation score. The evaluator may use different criteria. This edition addresses several weaknesses identified in the evaluation feedback, but no code can guarantee a particular evaluator score. Run the tests on your computer, verify the demo flows, and be ready to explain each feature.
