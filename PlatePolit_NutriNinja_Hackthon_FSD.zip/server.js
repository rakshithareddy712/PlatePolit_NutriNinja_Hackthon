const express = require("express");
const path = require("node:path");
const { randomUUID } = require("node:crypto");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { z } = require("zod");
const { initDatabase } = require("./src/database");
const { generatePlan, matchesDiet, score } = require("./src/planner");

const app = express();
const configuredRateLimit = Number.parseInt(process.env.API_RATE_LIMIT || "100", 10);
const apiRateLimit = Number.isInteger(configuredRateLimit) && configuredRateLimit > 0
  ? configuredRateLimit : 100;
app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "30kb", strict: true }));
app.use("/api", rateLimit({
  windowMs: 60_000,
  limit: apiRateLimit,
  standardHeaders: true,
  legacyHeaders: false
}));
app.use(express.static(path.join(__dirname, "public")));
app.use((req, res, next) => {
  req.requestId = randomUUID();
  res.setHeader("X-Request-Id", req.requestId);
  const startedAt = process.hrtime.bigint();
  res.on("finish", () => log("info", "http_request", {
    requestId: req.requestId,
    method: req.method,
    path: req.path,
    status: res.statusCode,
    durationMs: Number(process.hrtime.bigint() - startedAt) / 1e6
  }));
  next();
});

const log = (level, message, meta = {}) => {
  const entry = { timestamp: new Date().toISOString(), level, message, ...meta };
  (level === "error" ? console.error : console.log)(JSON.stringify(entry));
};

const planSchema = z.object({
  budget: z.coerce.number().finite().min(50).max(1000),
  diet: z.enum(["Vegetarian", "Non-Veg", "Vegan"]).default("Vegetarian"),
  goal: z.enum(["Maintenance", "Muscle Gain", "Weight Loss"]).default("Maintenance")
}).strict();

const swapSchema = z.object({
  mealId: z.string().min(1).max(30),
  currentIds: z.array(z.string().min(1).max(30)).max(10).default([]),
  budgetLeft: z.coerce.number().finite().min(0).max(1000),
  diet: z.enum(["Vegetarian", "Non-Veg", "Vegan"]).default("Vegetarian"),
  goal: z.enum(["Maintenance", "Muscle Gain", "Weight Loss"]).default("Maintenance")
}).strict();

const grocerySchema = z.object({
  meals: z.array(z.object({
    id: z.string().min(1).max(30),
    cost: z.number().finite().nonnegative().max(1000),
    ingredients: z.array(z.object({
      name: z.string().trim().min(1).max(80),
      qty: z.number().finite().nonnegative().max(100000)
    }).strict()).max(50)
  }).strict()).min(1).max(10)
}).strict();

let db, recipes;

async function createApp() {
  ({ db, recipes } = await initDatabase());

  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", database: "sqlite-wasm", recipeCount: recipes.length, uptimeSeconds: Math.floor(process.uptime()) });
  });

  app.get("/api/recipes", (_req, res) => res.json(recipes));

  app.post("/api/plan", (req, res, next) => {
    const parsed = planSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({
        error: "Check your budget, diet and goal values.",
        details: parsed.error.flatten()
      });
    }
    try {
      const meals = generatePlan({ ...parsed.data, recipes });
      const total = meals.reduce((sum, meal) => sum + meal.cost, 0);
      const planId = db.savePlan(parsed.data, meals, total);
      log("info", "meal_plan_created", { planId, total, diet: parsed.data.diet });
      return res.status(201).json({ meals, total, budget: parsed.data.budget, planId });
    } catch (error) {
      if (error instanceof RangeError || error.message.includes("Budget") ||
          error.message.includes("recipes available")) {
        return res.status(400).json({ error: error.message });
      }
      return next(error);
    }
  });

  app.post("/api/swap", (req, res) => {
    const parsed = swapSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid swap request." });
    const { mealId, currentIds, budgetLeft, diet, goal } = parsed.data;
    const current = recipes.find(recipe => recipe.id === mealId);
    if (!current) return res.status(404).json({ error: "Meal not found." });

    const alternative = recipes
      .filter(recipe => recipe.meal === current.meal &&
        recipe.id !== mealId && !currentIds.includes(recipe.id) &&
        matchesDiet(recipe, diet) && recipe.cost <= budgetLeft)
      .sort((a, b) => score(b, goal) - score(a, goal))[0];

    if (!alternative) {
      return res.status(404).json({ error: "No suitable alternative fits the remaining budget." });
    }
    return res.json(alternative);
  });

  app.post("/api/grocery", (req, res) => {
    const parsed = grocerySchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid grocery list request." });

    const items = new Map();
    for (const meal of parsed.data.meals) {
      for (const item of meal.ingredients) {
        const key = item.name.trim().toLocaleLowerCase("en");
        const existing = items.get(key);
        if (existing) existing.qty += item.qty;
        else items.set(key, { name: item.name.trim(), qty: item.qty });
      }
    }
    const list = [...items.values()].map(({ name, qty }) => ({
      name, qty, weeklyQty: qty * 7,
      category: /rice|roti|oats|bread|dalia|poha/i.test(name) ? "Grains" :
        /egg|soya|dal|chana|paneer|curd|milk|peanut/i.test(name)
          ? "Protein & Dairy" : "Produce & Other"
    })).sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name));

    return res.json({
      list,
      weeklyCost: parsed.data.meals.reduce((sum, meal) => sum + meal.cost, 0) * 7
    });
  });

  app.get("/api/history", (_req, res, next) => {
    try { return res.json(db.getHistory()); }
    catch (error) { return next(error); }
  });

  // Malformed JSON and unexpected errors are handled consistently.
  app.use((err, _req, res, _next) => {
    const isJsonError = err instanceof SyntaxError && err.status === 400 && "body" in err;
    const status = isJsonError ? 400 : 500;
    log(status === 500 ? "error" : "warn", "request_failed", {
      requestId: _req.requestId, status, message: err.message
    });
    return res.status(status).json({
      error: isJsonError ? "Request body contains invalid JSON." : "Something went wrong. Please try again.",
      requestId: _req.requestId
    });
  });

  return app;
}

module.exports = { createApp };
if (require.main === module) {
  createApp().then(application => {
    const port = Number(process.env.PORT || 3000);
    application.listen(port, () => log("info", "server_started", { port }));
  }).catch(error => {
    log("error", "startup_failed", { message: error.message });
    process.exitCode = 1;
  });
}
