const test = require("node:test");
const assert = require("node:assert/strict");
const request = require("supertest");
const { matchesDiet, score, generatePlan, MEAL_SLOTS } = require("../src/planner");
const { createApp } = require("../server");
const recipes = require("../data/recipes.json");

test("meal slots are explicit and ordered", () => {
  assert.deepEqual(MEAL_SLOTS, ["Breakfast", "Lunch", "Snack", "Dinner"]);
});

test("vegan filter only returns vegan recipes", () => {
  assert.equal(recipes.filter(r => matchesDiet(r, "Vegan")).every(r => r.type === "Vegan"), true);
});

test("vegetarian filter excludes non-vegetarian recipes", () => {
  assert.equal(recipes.filter(r => matchesDiet(r, "Vegetarian")).every(r => r.type !== "Non-Veg"), true);
});

test("non-veg preference accepts all recipe types", () => {
  assert.equal(recipes.filter(r => matchesDiet(r, "Non-Veg")).length, recipes.length);
});

test("generated plan has exactly one meal per slot and stays within budget", () => {
  const meals = generatePlan({ budget: 150, diet: "Vegetarian", goal: "Maintenance", recipes });
  assert.deepEqual(meals.map(m => m.meal), MEAL_SLOTS);
  assert.ok(meals.reduce((sum, meal) => sum + meal.cost, 0) <= 150);
});

test("low budget returns a useful minimum-budget error", () => {
  assert.throws(() => generatePlan({ budget: 50, diet: "Vegan", goal: "Maintenance", recipes }), /Budget too low/);
});

test("invalid budget is rejected by planner", () => {
  assert.throws(() => generatePlan({ budget: Infinity, diet: "Vegan", goal: "Maintenance", recipes }), /valid non-negative/);
});

test("goal scoring returns finite values for supported goals", () => {
  for (const goal of ["Maintenance", "Muscle Gain", "Weight Loss"]) {
    assert.equal(Number.isFinite(score(recipes[0], goal)), true);
  }
});

test("every recipe has required fields and unique id", () => {
  const ids = recipes.map(recipe => recipe.id);
  assert.equal(new Set(ids).size, ids.length);
  for (const recipe of recipes) {
    for (const field of ["name", "meal", "type", "cost", "calories", "protein", "ingredients", "steps"]) {
      assert.ok(recipe[field] !== undefined, `${recipe.id} is missing ${field}`);
    }
    assert.ok(recipe.cost >= 0);
    assert.ok(recipe.ingredients.length > 0);
    assert.ok(recipe.steps.length > 0);
  }
});

let app;
test("API integration: health and recipes endpoints", async () => {
  app = await createApp();
  const health = await request(app).get("/api/health").expect(200);
  assert.equal(health.body.status, "ok");
  assert.ok(health.body.recipeCount > 0);
  const response = await request(app).get("/api/recipes").expect(200);
  assert.ok(response.body.length > 0);
});

test("API integration: valid plan is created and saved", async () => {
  const response = await request(app).post("/api/plan")
    .send({ budget: 150, diet: "Vegetarian", goal: "Maintenance" })
    .expect(201);
  assert.equal(response.body.meals.length, 4);
  assert.ok(response.body.total <= response.body.budget);
  assert.ok(response.body.planId);
});

test("API rejects invalid plan input", async () => {
  await request(app).post("/api/plan")
    .send({ budget: -5, diet: "Carnivore", goal: "Unknown" })
    .expect(400);
});

test("API rejects malformed JSON", async () => {
  await request(app).post("/api/plan")
    .set("Content-Type", "application/json")
    .send('{"budget":')
    .expect(400);
});

test("API grocery aggregation combines ingredient quantities", async () => {
  const response = await request(app).post("/api/grocery").send({
    meals: [
      { id: "a", cost: 20, ingredients: [{ name: "Rice", qty: 50 }] },
      { id: "b", cost: 30, ingredients: [{ name: "rice", qty: 25 }] }
    ]
  }).expect(200);
  assert.equal(response.body.list.length, 1);
  assert.equal(response.body.list[0].qty, 75);
  assert.equal(response.body.weeklyCost, 350);
});

test("API rejects negative grocery quantities", async () => {
  await request(app).post("/api/grocery").send({
    meals: [{ id: "a", cost: 20, ingredients: [{ name: "Rice", qty: -1 }] }]
  }).expect(400);
});

test("API history returns saved plans", async () => {
  const response = await request(app).get("/api/history").expect(200);
  assert.ok(Array.isArray(response.body));
  assert.ok(response.body.length > 0);
});

test("API swaps a meal for a distinct option within the remaining budget", async () => {
  const first = recipes.find(r => r.meal === "Breakfast" && r.type === "Vegetarian");
  const used = recipes.filter(r => r.meal !== "Breakfast").slice(0, 3).map(r => r.id);
  const response = await request(app).post("/api/swap").send({
    mealId: first.id,
    currentIds: used,
    budgetLeft: 1000,
    diet: "Vegetarian",
    goal: "Maintenance"
  }).expect(200);
  assert.notEqual(response.body.id, first.id);
  assert.equal(response.body.meal, first.meal);
  assert.ok(response.body.cost <= 1000);
});

test("API returns 404 for an unknown meal swap", async () => {
  await request(app).post("/api/swap").send({
    mealId: "does-not-exist", currentIds: [], budgetLeft: 100,
    diet: "Vegetarian", goal: "Maintenance"
  }).expect(404);
});

test("API rejects unexpected fields instead of silently accepting them", async () => {
  await request(app).post("/api/plan").send({
    budget: 120, diet: "Vegetarian", goal: "Maintenance", admin: true
  }).expect(400);
});

test("health endpoint includes operational metadata", async () => {
  const response = await request(app).get("/api/health").expect(200);
  assert.equal(response.body.database, "sqlite-wasm");
  assert.ok(response.body.uptimeSeconds >= 0);
  assert.ok(response.headers["x-request-id"]);
});
