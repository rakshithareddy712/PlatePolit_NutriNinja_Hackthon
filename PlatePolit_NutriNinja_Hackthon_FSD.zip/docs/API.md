# PlatePilot API reference

Base URL: `http://localhost:3000`

All request bodies must be JSON. Invalid input returns HTTP `400`; missing resources return `404`. Error responses include a short message and, for unexpected server errors, a request ID that can be matched with the structured server log.

## `GET /api/health`
Returns service health, database type, recipe count, and process uptime.

## `GET /api/recipes`
Returns the recipe dataset used by the planner.

## `POST /api/plan`
Creates and persists one daily plan.

```json
{
  "budget": 150,
  "diet": "Vegetarian",
  "goal": "Maintenance"
}
```

- `budget`: number from 50 to 1000 (INR)
- `diet`: `Vegetarian`, `Non-Veg`, or `Vegan`
- `goal`: `Maintenance`, `Muscle Gain`, or `Weight Loss`

Success: `201` with `meals`, `total`, `budget`, and `planId`.

## `POST /api/swap`
Finds a different recipe in the same meal slot that fits the remaining budget.

```json
{
  "mealId": "recipe-id-to-replace",
  "currentIds": ["recipe-id-already-selected"],
  "budgetLeft": 45,
  "diet": "Vegetarian",
  "goal": "Maintenance"
}
```

Success: `200` with the replacement recipe. Returns `404` when the requested meal or a suitable alternative is unavailable.

## `POST /api/grocery`
Combines ingredients with case-insensitive names and estimates a seven-day cost.

```json
{
  "meals": [
    { "id": "meal-1", "cost": 30, "ingredients": [{ "name": "Rice", "qty": 50 }] }
  ]
}
```

Success: `200` with `list` and `weeklyCost`.

## `GET /api/history`
Returns the 20 most recent saved plans, newest first.

## Operational configuration

Copy `.env.example` as a reference for optional environment variables. Set `PORT` to change the listening port and `API_RATE_LIMIT` to change the maximum API requests per IP per minute. Environment variables are read by Node directly; no `.env` parser is included.
