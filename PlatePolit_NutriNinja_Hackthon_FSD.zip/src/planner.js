const MEAL_SLOTS = ["Breakfast", "Lunch", "Snack", "Dinner"];

function matchesDiet(recipe, diet) {
  if (diet === "Vegan") return recipe.type === "Vegan";
  if (diet === "Vegetarian") return recipe.type === "Vegetarian" || recipe.type === "Vegan";
  return ["Vegan", "Vegetarian", "Non-Veg"].includes(recipe.type);
}

function score(recipe, goal) {
  const proteinPerRupee = recipe.protein / Math.max(recipe.cost, 1);
  if (goal === "Muscle Gain") return proteinPerRupee * 3 + recipe.protein * 0.15;
  if (goal === "Weight Loss") return recipe.protein * 0.8 + recipe.fiber * 0.5 - recipe.calories * 0.001;
  return recipe.protein * 0.5 + recipe.fiber * 0.25;
}

function generatePlan({ budget, diet, goal, recipes }) {
  const dailyBudget = Number(budget);
  if (!Number.isFinite(dailyBudget) || dailyBudget < 0) {
    throw new RangeError("Budget must be a valid non-negative number.");
  }
  if (!Array.isArray(recipes) || recipes.length === 0) {
    throw new Error("There are no recipes available.");
  }

  const pools = MEAL_SLOTS.map(slot => recipes
    .filter(recipe => recipe.meal === slot && matchesDiet(recipe, diet))
    .sort((a, b) => score(b, goal) - score(a, goal)));

  if (pools.some(pool => pool.length === 0)) {
    throw new Error("There are no recipes available for one of the meal slots.");
  }

  const minimumTotal = pools.reduce((sum, pool) => sum + Math.min(...pool.map(r => r.cost)), 0);
  if (minimumTotal > dailyBudget) {
    throw new Error(`Budget too low. At least ₹${minimumTotal} is needed for this diet.`);
  }

  let remaining = dailyBudget;
  const selected = [];
  for (let index = 0; index < MEAL_SLOTS.length; index++) {
    const laterMinimum = pools.slice(index + 1)
      .reduce((sum, pool) => sum + Math.min(...pool.map(recipe => recipe.cost)), 0);
    const pick = pools[index].find(recipe => recipe.cost <= remaining - laterMinimum);
    if (!pick) throw new Error(`Budget too low to fill ${MEAL_SLOTS[index]}.`);
    selected.push({ ...pick });
    remaining -= pick.cost;
  }
  return selected;
}

module.exports = { MEAL_SLOTS, matchesDiet, score, generatePlan };
