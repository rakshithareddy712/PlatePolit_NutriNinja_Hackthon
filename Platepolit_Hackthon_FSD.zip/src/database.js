const fs = require("fs");
const path = require("path");
const initSqlJs = require("sql.js");

async function initDatabase() {
  const SQL = await initSqlJs();
  const dataDir = path.join(__dirname, "..", "data");
  const dbPath = path.join(dataDir, "platepilot.sqlite");
  fs.mkdirSync(dataDir, { recursive: true });
  const db = fs.existsSync(dbPath) ? new SQL.Database(fs.readFileSync(dbPath)) : new SQL.Database();
  db.run(`CREATE TABLE IF NOT EXISTS meal_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL,
    budget REAL NOT NULL, diet TEXT NOT NULL, goal TEXT NOT NULL,
    total REAL NOT NULL, meals_json TEXT NOT NULL
  )`);
  const persist = () => fs.writeFileSync(dbPath, Buffer.from(db.export()));
  persist();

  const recipeFile = path.join(dataDir, "recipes.json");
  const recipes = JSON.parse(fs.readFileSync(recipeFile, "utf8"));
  const api = {
    savePlan(profile, meals, total) {
      const stmt = db.prepare("INSERT INTO meal_plans (created_at,budget,diet,goal,total,meals_json) VALUES (?,?,?,?,?,?)");
      stmt.run([new Date().toISOString(), profile.budget, profile.diet, profile.goal, total, JSON.stringify(meals)]);
      stmt.free(); const id = db.exec("SELECT last_insert_rowid() AS id")[0].values[0][0]; persist(); return id;
    },
    getHistory() {
      const result = db.exec("SELECT id,created_at,budget,diet,goal,total,meals_json FROM meal_plans ORDER BY id DESC LIMIT 20");
      if (!result.length) return [];
      return result[0].values.map(([id,created_at,budget,diet,goal,total,meals_json]) =>
        ({ id, createdAt: created_at, budget, diet, goal, total, meals: JSON.parse(meals_json) }));
    }
  };
  return { db: api, recipes };
}
module.exports = { initDatabase };
