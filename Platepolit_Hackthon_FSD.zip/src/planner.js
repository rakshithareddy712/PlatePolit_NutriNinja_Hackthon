function matchesDiet(recipe, diet) {
  if (diet === "Vegan") return recipe.type === "Vegan";
  if (diet === "Vegetarian") return recipe.type === "Vegetarian" || recipe.type === "Vegan";
  // Non-Veg means the user accepts all food types, not that every meal must contain meat/eggs.
  return ["Vegan", "Vegetarian", "Non-Veg"].includes(recipe.type);
}
function score(recipe, goal) {
  const proteinPerRupee = recipe.protein / Math.max(recipe.cost, 1);
  if (goal === "Muscle Gain") return proteinPerRupee * 3 + recipe.protein * 0.15;
  if (goal === "Weight Loss") return recipe.protein * 0.8 + recipe.fiber * 0.5 - recipe.calories * 0.001;
  return recipe.protein * 0.5 + recipe.fiber * 0.25;
}
function generatePlan({ budget, diet, goal, recipes }) {
  const slots = ["Breakfast", "Lunch", "Snack", "Dinner"];
  const pools = slots.map(slot => recipes.filter(r => r.meal === slot && matchesDiet(r, diet))
    .sort((a,b) => score(b, goal)-score(a, goal)));
  if (pools.some(pool => pool.length === 0)) throw new Error("There are no recipes available for one of the meal slots.");
  let selected = [], remaining = Number(budget);
  for (let i=0; i<slots.length; i++) {
    const laterMin = pools.slice(i+1).reduce((sum,p) => sum + Math.min(...p.map(r=>r.cost)), 0);
    const pick = pools[i].find(r => r.cost <= remaining - laterMin) || pools[i].find(r => r.cost <= remaining);
    if (!pick) throw new Error(`Budget too low to fill ${slots[i]}. Try increasing your daily budget.`);
    selected.push({ ...pick }); remaining -= pick.cost;
  }
  return selected;
}
module.exports = { matchesDiet, score, generatePlan };
