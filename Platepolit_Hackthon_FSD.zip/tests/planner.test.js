const test = require("node:test");
const assert = require("node:assert/strict");
const { matchesDiet, score, generatePlan } = require("../src/planner");
const recipes = require("../data/recipes.json");

test("vegan filter only returns vegan recipes", () => {
  assert.equal(recipes.filter(r => matchesDiet(r, "Vegan")).every(r => r.type === "Vegan"), true);
});
test("vegetarian filter excludes non-vegetarian recipes", () => {
  assert.equal(recipes.filter(r => matchesDiet(r, "Vegetarian")).every(r => r.type !== "Non-Veg"), true);
});
test("non-veg preference accepts all recipe types", () => {
  assert.equal(recipes.filter(r => matchesDiet(r, "Non-Veg")).length, recipes.length);
});
test("plan has one meal per slot and stays within budget", () => {
  const meals = generatePlan({ budget: 150, diet: "Vegetarian", goal: "Maintenance", recipes });
  assert.deepEqual(meals.map(m => m.meal), ["Breakfast","Lunch","Snack","Dinner"]);
  assert.ok(meals.reduce((sum,m)=>sum+m.cost,0) <= 150);
});
test("low budget returns a clear error", () => {
  assert.throws(() => generatePlan({ budget: 50, diet: "Vegan", goal: "Maintenance", recipes }), /Budget too low/);
});
test("goal scoring returns a numeric value", () => {
  assert.equal(Number.isFinite(score(recipes[0], "Muscle Gain")), true);
});
