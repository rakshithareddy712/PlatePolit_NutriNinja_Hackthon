const express = require("express");
const path = require("path");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { z } = require("zod");
const { initDatabase } = require("./src/database");
const { generatePlan, matchesDiet, score } = require("./src/planner");

const app = express();
app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false })); // Chart.js is loaded from a CDN in the demo UI.
app.use(express.json({ limit: "30kb" }));
app.use("/api", rateLimit({ windowMs: 60_000, limit: 100, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(__dirname, "public")));

const planSchema = z.object({
  budget: z.coerce.number().finite().min(50).max(1000),
  diet: z.enum(["Vegetarian", "Non-Veg", "Vegan"]).default("Vegetarian"),
  goal: z.enum(["Maintenance", "Muscle Gain", "Weight Loss"]).default("Maintenance")
}).strict();

const swapSchema = z.object({
  mealId: z.string().min(1).max(30),
  currentIds: z.array(z.string().max(30)).max(10).default([]),
  budgetLeft: z.coerce.number().finite().min(0).max(1000),
  diet: z.enum(["Vegetarian", "Non-Veg", "Vegan"]).default("Vegetarian"),
  goal: z.enum(["Maintenance", "Muscle Gain", "Weight Loss"]).default("Maintenance")
}).strict();

const grocerySchema = z.object({
  meals: z.array(z.object({
    id: z.string(), cost: z.number().nonnegative(),
    ingredients: z.array(z.object({ name: z.string().min(1).max(80), qty: z.number().finite().nonnegative() }))
  })).max(10)
}).strict();

let db, recipes;
async function createApp() {
  ({ db, recipes } = await initDatabase());
  app.get("/api/health", (_req, res) => res.json({ status: "ok", database: "sqlite-wasm" }));
  app.get("/api/recipes", (_req, res) => res.json(recipes));

  app.post("/api/plan", (req, res) => {
    const parsed = planSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Check your budget, diet and goal values.", details: parsed.error.flatten() });
    try {
      const meals = generatePlan({ ...parsed.data, recipes });
      const total = meals.reduce((sum, meal) => sum + meal.cost, 0);
      const saved = db.savePlan(parsed.data, meals, total);
      res.status(201).json({ meals, total, budget: parsed.data.budget, planId: saved });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/swap", (req, res) => {
    const parsed = swapSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid swap request." });
    const { mealId, currentIds, budgetLeft, diet, goal } = parsed.data;
    const current = recipes.find(r => r.id === mealId);
    if (!current) return res.status(404).json({ error: "Meal not found." });
    const alternative = recipes.filter(r => r.meal === current.meal && r.id !== mealId &&
      !currentIds.includes(r.id) && matchesDiet(r, diet) && r.cost <= budgetLeft)
      .sort((a, b) => score(b, goal) - score(a, goal))[0];
    if (!alternative) return res.status(404).json({ error: "No suitable alternative fits the remaining budget." });
    res.json(alternative);
  });

  app.post("/api/grocery", (req, res) => {
    const parsed = grocerySchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid grocery list request." });
    const items = new Map();
    for (const meal of parsed.data.meals) for (const item of meal.ingredients) {
      items.set(item.name, (items.get(item.name) || 0) + item.qty);
    }
    const list = [...items].map(([name, qty]) => ({
      name, qty, weeklyQty: qty * 7,
      category: /rice|roti|oats|bread|dalia|poha/i.test(name) ? "Grains" :
        /egg|soya|dal|chana|paneer|curd|milk|peanut/i.test(name) ? "Protein & Dairy" : "Produce & Other"
    })).sort((a,b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name));
    res.json({ list, weeklyCost: parsed.data.meals.reduce((sum, meal) => sum + meal.cost, 0) * 7 });
  });

  app.get("/api/history", (_req, res) => res.json(db.getHistory()));
  app.use((err, _req, res, _next) => {
    console.error(err.message);
    res.status(500).json({ error: "Something went wrong. Please try again." });
  });
  return app;
}
module.exports = { createApp };
if (require.main === module) {
  createApp().then(app => {
    const port = process.env.PORT || 3000;
    app.listen(port, () => console.log(`PlatePilot running at http://localhost:${port}`));
  }).catch(err => { console.error("Startup failed:", err); process.exit(1); });
}
