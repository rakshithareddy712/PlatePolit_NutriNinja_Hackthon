const fs = require("node:fs");
const path = require("node:path");
const initSqlJs = require("sql.js");

function atomicWrite(filePath, contents) {
  const tempPath = `${filePath}.${process.pid}.tmp`;
  try {
    fs.writeFileSync(tempPath, contents, { flag: "w" });
    fs.renameSync(tempPath, filePath);
  } catch (error) {
    try { fs.rmSync(tempPath, { force: true }); } catch (_) { /* best-effort cleanup */ }
    throw error;
  }
}

async function initDatabase() {
  const SQL = await initSqlJs();
  const dataDir = path.join(__dirname, "..", "data");
  const dbPath = path.join(dataDir, "platepilot.sqlite");
  fs.mkdirSync(dataDir, { recursive: true });

  let database = fs.existsSync(dbPath)
    ? new SQL.Database(fs.readFileSync(dbPath))
    : new SQL.Database();

  database.run(`CREATE TABLE IF NOT EXISTS meal_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    budget REAL NOT NULL CHECK (budget >= 0),
    diet TEXT NOT NULL,
    goal TEXT NOT NULL,
    total REAL NOT NULL CHECK (total >= 0),
    meals_json TEXT NOT NULL
  )`);
  database.run("CREATE INDEX IF NOT EXISTS idx_meal_plans_created_at ON meal_plans(created_at DESC)");
  atomicWrite(dbPath, Buffer.from(database.export()));

  const recipeFile = path.join(dataDir, "recipes.json");
  let recipes;
  try {
    recipes = JSON.parse(fs.readFileSync(recipeFile, "utf8"));
  } catch (error) {
    throw new Error(`Unable to read recipe dataset: ${error.message}`);
  }
  if (!Array.isArray(recipes) || recipes.length === 0) {
    throw new Error("Recipe dataset must be a non-empty JSON array.");
  }
  const ids = new Set();
  for (const recipe of recipes) {
    if (!recipe || typeof recipe.id !== "string" || !recipe.id.trim() || ids.has(recipe.id)) {
      throw new Error("Every recipe must have a unique, non-empty string ID.");
    }
    ids.add(recipe.id);
    for (const field of ["name", "meal", "type"]) {
      if (typeof recipe[field] !== "string" || !recipe[field].trim()) {
        throw new Error(`Recipe ${recipe.id} has an invalid ${field}.`);
      }
    }
    for (const field of ["cost", "calories", "protein", "carbs", "fat", "time"]) {
      if (!Number.isFinite(recipe[field]) || recipe[field] < 0) {
        throw new Error(`Recipe ${recipe.id} has an invalid ${field}.`);
      }
    }
    if (!Array.isArray(recipe.ingredients) || !Array.isArray(recipe.steps)) {
      throw new Error(`Recipe ${recipe.id} must include ingredients and steps arrays.`);
    }
  }

  const api = {
    savePlan(profile, meals, total) {
      // Work on a clone so a failed disk write cannot leave memory and disk out of sync.
      const candidate = new SQL.Database(database.export());
      try {
        candidate.run("BEGIN IMMEDIATE TRANSACTION");
        const stmt = candidate.prepare(
          "INSERT INTO meal_plans (created_at,budget,diet,goal,total,meals_json) VALUES (?,?,?,?,?,?)"
        );
        try {
          stmt.run([
            new Date().toISOString(), profile.budget, profile.diet,
            profile.goal, total, JSON.stringify(meals)
          ]);
        } finally {
          stmt.free();
        }
        const id = candidate.exec("SELECT last_insert_rowid() AS id")[0].values[0][0];
        candidate.run("COMMIT");
        atomicWrite(dbPath, Buffer.from(candidate.export()));
        database.close();
        database = candidate;
        return id;
      } catch (error) {
        try { candidate.run("ROLLBACK"); } catch (_) { /* transaction may already be closed */ }
        candidate.close();
        throw error;
      }
    },

    getHistory() {
      const result = database.exec(
        "SELECT id,created_at,budget,diet,goal,total,meals_json FROM meal_plans ORDER BY id DESC LIMIT 20"
      );
      if (!result.length) return [];
      return result[0].values.map(([id, createdAt, budget, diet, goal, total, mealsJson]) => ({
        id, createdAt, budget, diet, goal, total, meals: JSON.parse(mealsJson)
      }));
    },

    clearHistory() {
      const candidate = new SQL.Database(database.export());
      try {
        candidate.run("BEGIN IMMEDIATE TRANSACTION");
        candidate.run("DELETE FROM meal_plans");
        candidate.run("COMMIT");
        atomicWrite(dbPath, Buffer.from(candidate.export()));
        database.close();
        database = candidate;
      } catch (error) {
        try { candidate.run("ROLLBACK"); } catch (_) {}
        candidate.close();
        throw error;
      }
    }
  };

  return { db: api, recipes };
}
module.exports = { initDatabase };
