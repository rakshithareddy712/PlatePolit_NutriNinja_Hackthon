let currentPlan = [];
let currentBudget = 120;
let chart = null;

const $ = id => document.getElementById(id);

const escapeHTML = value =>
  String(value).replace(/[&<>"']/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }[c]));

function setError(message) {
  $("error").textContent = message || "";
}

function getValidatedFormValues() {
  const rawBudget = Number($("budget").value);
  if (!Number.isFinite(rawBudget) || rawBudget < 50 || rawBudget > 1000) {
    return { error: "Please enter a daily budget between ₹50 and ₹1,000." };
  }
  const diet = $("diet").value;
  const goal = $("goal").value;
  return { budget: rawBudget, diet, goal };
}

function calculateTotals(meals = currentPlan) {
  return meals.reduce((acc, meal) => {
    acc.calories += Number(meal.calories) || 0;
    acc.protein += Number(meal.protein) || 0;
    acc.carbs += Number(meal.carbs) || 0;
    acc.fat += Number(meal.fat) || 0;
    acc.cost += Number(meal.cost) || 0;
    return acc;
  }, { calories: 0, protein: 0, carbs: 0, fat: 0, cost: 0 });
}

function renderStats(totals) {
  const cards = [
    ["Estimated calories", `${totals.calories} kcal`],
    ["Protein", `${totals.protein} g`],
    ["Carbohydrates", `${totals.carbs} g`],
    ["Fat", `${totals.fat} g`]
  ];
  $("stats").innerHTML = cards
    .map(([label, val]) => `<div class="stat"><small>${escapeHTML(label)}</small><strong>${escapeHTML(val)}</strong></div>`)
    .join("");
}

function renderMeals() {
  $("mealGrid").innerHTML = currentPlan.map(meal => {
    const ingredientsHtml = (meal.ingredients || [])
      .map(item => `${escapeHTML(item.name)} (${escapeHTML(item.qty)})`)
      .join(", ");
    const stepsHtml = (meal.steps || [])
      .map(step => `<li>${escapeHTML(step)}</li>`)
      .join("");

    return `
      <article class="meal" data-meal-id="${escapeHTML(meal.id)}">
        <div class="meal-top">
          <div>
            <div class="eyebrow">${escapeHTML(String(meal.meal || "").toUpperCase())}</div>
            <h3>${escapeHTML(meal.name)}</h3>
          </div>
          <div class="cost">₹${escapeHTML(meal.cost)}</div>
        </div>
        <div class="meal-meta">⏱ ${escapeHTML(meal.time)} min • ${escapeHTML(meal.type)}</div>
        <div class="macroline">
          <span>🔥 ${escapeHTML(meal.calories)} kcal</span>
          <span>💪 ${escapeHTML(meal.protein)}g protein</span>
          <span>🍚 ${escapeHTML(meal.carbs)}g carbs</span>
          <span>🥑 ${escapeHTML(meal.fat)}g fat</span>
        </div>
        <details>
          <summary>Ingredients & simple instructions</summary>
          <p><b>Ingredients:</b> ${ingredientsHtml}</p>
          <ol>${stepsHtml}</ol>
        </details>
        <button class="swap" type="button" data-swap-id="${escapeHTML(meal.id)}">
          ↻ Swap ${escapeHTML(meal.meal)}
        </button>
      </article>
    `;
  }).join("");
}

function drawChart(totals) {
  if (!window.Chart) return;
  if (chart) {
    chart.destroy();
    chart = null;
  }
  const canvas = $("macroChart");
  if (!canvas) return;

  chart = new Chart(canvas, {
    type: "doughnut",
    data: {
      labels: ["Protein", "Carbs", "Fat"],
      datasets: [{
        data: [totals.protein * 4, totals.carbs * 4, totals.fat * 9],
        backgroundColor: ["#1d7652", "#d9a441", "#a6c96a"],
        borderWidth: 0
      }]
    },
    options: {
      cutout: "65%",
      plugins: {
        legend: { position: "bottom" }
      }
    }
  });
}

function renderPlanView(total, budget) {
  $("results").classList.remove("hidden");
  $("budgetPill").textContent = `₹${total} / ₹${budget}`;
  const totals = calculateTotals(currentPlan);
  renderStats(totals);
  renderMeals();
  drawChart(totals);
  loadGroceries();
}

async function handlePlanSubmit(event) {
  event.preventDefault();
  setError("");

  const values = getValidatedFormValues();
  if (values.error) {
    setError(values.error);
    return;
  }

  const button = $("generateBtn");
  button.disabled = true;
  button.textContent = "Generating...";

  try {
    const res = await fetch("/api/plan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values)
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || "Unable to generate meal plan.");
    }
    currentPlan = Array.isArray(data.meals) ? data.meals : [];
    currentBudget = Number(data.budget);
    renderPlanView(Number(data.total), currentBudget);
    await loadHistory();
  } catch (err) {
    setError(err.message || "Network error while generating plan.");
  } finally {
    button.disabled = false;
    button.textContent = "✨ Generate my meal plan";
  }
}

async function handleMealGridClick(event) {
  const swapBtn = event.target.closest("button[data-swap-id]");
  if (!swapBtn) return;

  const mealId = swapBtn.getAttribute("data-swap-id");
  const targetMeal = currentPlan.find(item => item.id === mealId);
  if (!targetMeal) return;

  const usedIds = currentPlan.filter(item => item.id !== mealId).map(item => item.id);
  const spentWithoutTarget = currentPlan
    .filter(item => item.id !== mealId)
    .reduce((sum, item) => sum + (Number(item.cost) || 0), 0);
  const budgetLeft = Math.max(0, currentBudget - spentWithoutTarget);

  swapBtn.disabled = true;
  const originalLabel = swapBtn.textContent;
  swapBtn.textContent = "Swapping...";
  setError("");

  try {
    const res = await fetch("/api/swap", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        mealId,
        currentIds: usedIds,
        budgetLeft,
        diet: $("diet").value,
        goal: $("goal").value
      })
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error || "Could not swap this meal.");
      return;
    }
    currentPlan = currentPlan.map(item => (item.id === mealId ? data : item));
    renderPlanView(calculateTotals(currentPlan).cost, currentBudget);
  } catch (err) {
    setError(err.message || "Unable to swap meal right now.");
  } finally {
    swapBtn.disabled = false;
    swapBtn.textContent = originalLabel;
  }
}

async function loadGroceries() {
  if (!currentPlan.length) return;
  try {
    const res = await fetch("/api/grocery", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ meals: currentPlan })
    });
    const data = await res.json();
    if (!res.ok) {
      $("groceryList").innerHTML = `<p class="error">${escapeHTML(data.error || "Unable to build grocery list.")}</p>`;
      return;
    }

    const header = `<p class="muted">Estimated 7-day spend if this same day is repeated: <b>₹${escapeHTML(data.weeklyCost)}</b></p>`;
    const rows = (data.list || [])
      .map(item => `
        <div class="grocery-item">
          <span>${escapeHTML(item.name)} <small>· ${escapeHTML(item.category)}</small></span>
          <b>${escapeHTML(item.weeklyQty)} units/week</b>
        </div>
      `)
      .join("");
    $("groceryList").innerHTML = header + (rows || `<p class="muted">No ingredients found.</p>`);
  } catch (_) {
    $("groceryList").innerHTML = `<p class="muted">Grocery list unavailable right now.</p>`;
  }
}

async function loadHistory() {
  try {
    const res = await fetch("/api/history");
    const history = await res.json();
    if (!res.ok || !Array.isArray(history)) {
      $("historyList").innerHTML = `<p class="muted">Could not load saved meal plans.</p>`;
      return;
    }
    if (!history.length) {
      $("historyList").innerHTML = `<p class="muted">Your generated plans will appear here.</p>`;
      return;
    }
    $("historyList").innerHTML = history
      .map(plan => {
        const dateStr = new Date(plan.createdAt).toLocaleString();
        return `
          <div class="grocery-item">
            <span>${escapeHTML(dateStr)} · ${escapeHTML(plan.diet)} · ${escapeHTML(plan.goal)}</span>
            <b>₹${escapeHTML(plan.total)} / ₹${escapeHTML(plan.budget)}</b>
          </div>
        `;
      })
      .join("");
  } catch (_) {
    $("historyList").innerHTML = `<p class="muted">History unavailable right now.</p>`;
  }
}

async function clearHistory() {
  const btn = $("clearHistoryBtn");
  btn.disabled = true;
  try {
    const res = await fetch("/api/history", { method: "DELETE" });
    if (res.ok) {
      await loadHistory();
    }
  } finally {
    btn.disabled = false;
  }
}

$("profileForm").addEventListener("submit", handlePlanSubmit);
$("mealGrid").addEventListener("click", handleMealGridClick);
$("printBtn").addEventListener("click", () => window.print());
$("clearHistoryBtn").addEventListener("click", clearHistory);

loadHistory();
